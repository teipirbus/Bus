package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.GroupLayout;

import userAuthentication.UserAuthentication;


public class SystemEntrance extends javax.swing.JFrame {

    /**
     * Creates new form SystemEntrance
     */

	UserAuthentication userAuthentication;

    public SystemEntrance() {

    	super("System Entrance");

    	userAuthentication = new UserAuthentication();

        initComponents();
    }


    //******* Fotis functions.
    private ActionListener enterActionListener() {

        return new ActionListener(){

			public void actionPerformed( ActionEvent e ){

				if( jTextField1.getText() == null || ( jTextField1.getText() != null && jTextField1.getText().equals( "" ) ) ) JOptionPane.showMessageDialog( null, "You did not enter a user name.");

				else if( jTextField1.getText() != null ) System.out.println( jTextField1.getText() );


				if( jPasswordField2.getText() == null || ( jPasswordField2.getText() != null && jPasswordField2.getText().equals( "" ) ) ) JOptionPane.showMessageDialog( null, "You did not enter a password.");

				else if( jPasswordField2.getText() != null && ! jPasswordField2.getText().toString().equals( "" ) ) System.out.println( jPasswordField2.getText().toString() );


				if( jRadioButton1.isSelected() ){

					boolean result = userAuthentication.isAdministrator( jTextField1.getText(), jPasswordField2.getText().toString() );

					if( result == true ) new AdministratorEmployeeAccount( jTextField1.getText() );

					else JOptionPane.showMessageDialog( null, "Username and/or password are not correct.");
				}

				else if( jRadioButton2.isSelected() ) new AdministratorEmployeeAccount( jTextField1.getText() );

				else if( jRadioButton3.isSelected() ) System.out.println( "Driver" );

				else JOptionPane.showMessageDialog( null, "You did not select a category.");
    	   	}
        };
    }
    //******* Fotis functions.

    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();

        jPanel1 = new javax.swing.JPanel();
        jPanel1.setBorder( BorderFactory.createBevelBorder( 1 ) );

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();

        jButton1 = new javax.swing.JButton();
        jButton1.addActionListener( enterActionListener() );
        
        jButton2 = new javax.swing.JButton();
        jButton2.addActionListener( new ActionListener(){ public void actionPerformed( ActionEvent e ){ System.exit( 0 ); } } );

        jTextField1 = new javax.swing.JTextField();
        jPasswordField2 = new javax.swing.JPasswordField();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("User Login");

        jLabel3.setText("User name: ");

        jLabel4.setText("Password:");

        jLabel5.setText("User category:");

        jRadioButton1.setText("Administrator");

        jRadioButton2.setText("Employee");

        jRadioButton3.setText("Driver");
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });

        jButton1.setText("Enter");

        jButton2.setText("Cancel");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(jLabel1)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(17)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING, false)
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        								.addComponent(jLabel3)
        								.addComponent(jLabel4))
        							.addPreferredGap(ComponentPlacement.RELATED)
        							.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        								.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 133, GroupLayout.PREFERRED_SIZE)
        								.addComponent(jPasswordField2)))
        						.addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
        							.addComponent(jLabel5)
        							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        							.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        								.addComponent(jRadioButton2)
        								.addComponent(jRadioButton1)
        								.addComponent(jRadioButton3)))))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(254)
        					.addComponent(jButton1)
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(jButton2)))
        			.addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(0, 15, Short.MAX_VALUE)
        			.addComponent(jLabel1)
        			.addGap(18)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel3)
        				.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addPreferredGap(ComponentPlacement.UNRELATED)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel4)
        					.addGap(18)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(jLabel5)
        						.addComponent(jRadioButton1)))
        				.addComponent(jPasswordField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jRadioButton2)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jRadioButton3)
        			.addGap(28)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jButton1)
        				.addComponent(jButton2)))
        );
        jPanel1.setLayout(jPanel1Layout);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SystemEntrance().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JPasswordField jPasswordField2;
    // End of variables declaration//GEN-END:variables
}
