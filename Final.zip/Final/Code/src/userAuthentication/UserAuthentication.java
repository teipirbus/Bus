package userAuthentication;

import javax.swing.JOptionPane;


public class UserAuthentication {


	private String administratorUsername, adminisstratorPassword;

	private String[][] employees, drivers;
    private String[] bus;
	private int employeeCounter = 0, driverCounter = 0,busCounter=0;;


	//Constructor
	public UserAuthentication(){

		administratorUsername = "fotis";

		adminisstratorPassword = "savalia";
	}


	//Methods.
	public boolean isAdministrator( String username, String password ){

		if( username.equals( administratorUsername ) && password.equals( adminisstratorPassword ) ) return true;

		else return false;
	}

	public boolean isEmployee( String username, String password ){

		for( int i = 0; i < employees.length; ++i ) if( username.equals( employees[ i ][ 0 ] ) && password.equals( employees[ i ][ 1 ] ) ) return true;

		return false;
	}
	public boolean isDriver( String username, String bus_code){

		for( int i = 0; i < drivers.length; ++i ) if( username.equals( drivers[ i ][ 0 ] ) && bus_code.equals( drivers[ i ][ 1 ] ) ) return true;

		return false;
	}

	public void addEmployee( String username, String password ){

		if( employees == null ) employees = new String[ 1000 ][ 2 ];


		employees[ employeeCounter ][ 0 ] = username;

		employees[ employeeCounter ][ 1 ] = password;

		employeeCounter++;
	}
	public void addDriver( String username, String bus_code ){

		if( drivers == null ) drivers = new String[ 1000 ][ 2 ];


		drivers[ driverCounter ][ 0 ] = username;
		for( int i = 0; i < bus.length; ++i ) if( bus_code.equals( bus[ i ] ) ) {
			drivers[ driverCounter ][ 1 ] = bus_code;
		}
			else{ JOptionPane.showMessageDialog( null, "bus does not exist");}
		

		driverCounter++;
	}
		public void addBus(String BusCode ){

			if( bus == null ) bus = new String[ 1000 ];


			bus[ busCounter ] = BusCode;

			busCounter++;
	}
	public void deleteDriver (String username, String bus_code){
		for( int i = 0; i < drivers.length; ++i ) if( username.equals( drivers[ i ][ 0 ] ) && bus_code.equals( drivers[ i ][ 1 ] ) ) {
			drivers[i][0] = null;
			drivers[i][1] = null;}
			else{ JOptionPane.showMessageDialog( null, "driver does not exist");
		}
	}
		public void deleteBus (String BusCode){
			for( int i = 0; i < bus.length; ++i ) if( BusCode.equals( bus[ i ] ) ) {
				bus[i]= null;
			}
				else{ JOptionPane.showMessageDialog( null, "driver does not exist");
			}	

		
	}
}
